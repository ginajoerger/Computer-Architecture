//Author: Gina Joerger
//Purpose of Program: To tranition from Assembly to C

#include "given/bar.h"

long bar(long a, long b){
	long c = a; //movq %rdi, %rdx
	long d = 5 * a; //leaq (%rdi, %rdi, 4), %rcx

	d = 2 * d + a; //leaq (%rdi, %rcx, 2), rcx
	a = 16 * b; //%rsi, %rdi; shlq $4, %rdi
	d += 2 * b; //leaq (%rcx, %rsi, 2), %rcx
	d -= a; //subq %rdi, %rcx
	d += 1; //addq $1, $rcx

	long e = 0; 
	while (c <= b){
		c += 1; //addq $1, %rdx
		e += d; //addq %rcx, %rax
	}
	return e;
}
//Author: Gina Joerger

//Purpose of Program: This program performs basic operations on floating point numbers
//to illustrate how they are encoded using IEEE754 standard. It reads a sequence of floating
//point numbers from the standard input stream and outputs the results to the standard output stream.
//The input is terminated by a zero.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "float.h"


int is_special ( float f ) {
//Function Parameters: A float
//Returned Value: 1 or 0
//Summary of Function: Figure out if f is a special value.
    int beg2, beg3;

    unsigned int * beg = (unsigned int*) &f;
    beg2 = (* beg & 0x7f800000);
    beg3 = beg2 >> 23;

    if (beg3 == 0xFF) {
    	return 1;
    } else {
    	return 0;
    }
}


float get_M  ( float f ) {
//Function Parameters: A float.
//Returned Value: Float that has been adjusted to the mantissa/significand
//Purpose of Function: Get the mantissa/significand of the given float (return the fractional part of IEEE)
    float x;
    int beg2, beg3, beg4;

    x = f;
    unsigned int * beg = (unsigned int *) &x;
    * beg = * beg & 0x007FFFFF;

    beg2 = (127 << 23);
    * beg = (* beg)|beg2;

    beg3 = get_E(f);
    if (beg3 == -126) {
    	x = x - 1;
    }

    beg4 = is_special(f);
    if (beg4 == 1) {
    	x = x - 1;
    }
    return x;
}


int get_s ( float f ) {
//Function Parameters: A float
//Returned Value: The float that has been adjusted to give the sign (either 1 or -1)
//Purpose of Function: Compute the value of the sign.
    int beg2;

    unsigned int * beg = (unsigned int *) &f;
	beg2 = * beg >> 31;

	if (beg2 == 0) {
		return 1;
	} else {
		return -1;
	}
}


int get_E ( float f ) {
//Function Parameters: A float
//Returned Value: The exponent of the given float
//Purpose of Function: Compute and return the exponent.
    int beg2;
    int beg3;
    int nani;

    unsigned int * beg = (unsigned int*) &f;
    beg2 = (* beg & 0x7f800000);
    beg3 = beg2 >> 23;

    nani = is_special(f);

    if (nani == 0) {
    	if (beg3 == 0){
    		beg3 = beg3 - 126;
    	} else {
    		beg3 = beg3 - 127;
    	}
    	return beg3;
    } else {
    	return beg3;
    }
}

    
    

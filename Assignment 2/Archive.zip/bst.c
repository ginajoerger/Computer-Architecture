//Author: Gina Joerger

//Purpose of Program: The purpose of this program is to perform basic operations on a binary tree.
//It reads a sequence of intructions from the standard input stream and outputs the results to the 
//standard output stream.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bst.h"

void add ( bst_node ** root, char * word ) {
//Function Parameters: Taking in the root of a node and a word.
//Returned Value: Nothing, simply adds a word into the given binary tree.
//Summary of Function: This function takes a word and adds it to the appropriate location in the binary tree.
	if (*root == NULL){ //If there is no existing root
		bst_node * new_node = (bst_node *)malloc(sizeof(bst_node)); //Create memory storage for the incoming node.
		new_node -> left = NULL; //Set its left child to null.
		new_node -> right = NULL; //Set its right child to null.
		new_node -> data = word; //Set its data to the data given in the parameter.
		*root = new_node; //The root is now the newly created node.
		return; //Job completed.
	} else if (strcmp((*root) -> data, word) > 0){ //Comparison with word on the left.
		if ((*root) -> left == NULL){ //If the left node is empty
			bst_node * new_node = (bst_node *)malloc(sizeof(bst_node)); //Allocate memory for the incoming node.
			new_node -> left = NULL; //This new node's left child is set to NULL.
			new_node -> right = NULL; //This new node's right child is set to NULL.
			new_node -> data = word; //Node's value is set.
			(*root) -> left = new_node; //The left node is now the inputted data.
		} else {
			add(&((*root) -> left), word); //Recursion until this is applicable.
		}
	} else if (strcmp((*root) -> data, word) < 0){ // Comparison with word on the right.
		if ((*root) -> right == NULL){ //If the right node is empty
			bst_node * new_node = (bst_node *)malloc(sizeof(bst_node)); //Allocate memory for the incoming node.
			new_node -> left = NULL; //This new node's left child is set to NULL.
			new_node -> right =  NULL; //This new node's right child is set to NULL.
			new_node -> data = word; //Node's value is set.
			(*root) -> right = new_node; //The right node is now the inputted data.
		} else {
			add(&((*root) -> right), word); //Recursion until this is applicable.
		}
	}

}
 
void inorder ( bst_node * root ) { 
//Function Parameter: The root of the incoming node.
//Returned Value: Prints every item in the binary tree in inorder method.
//Summary of Function: Loops through tree in inorder order and prints all the values.
    if (root == NULL) { //If there is nothing in the root, return.
    	return;
    }
    inorder(root -> left); //Recursion for the left child.
    printf("%s ", root -> data); //Print the data
    inorder(root -> right); //Recursion for the right child.
}
 
char * removeSmallest (  bst_node ** root ){
//Function Parameters: The root of the entire binary tree.
//Returned Value: The item that was removed, even though it never is printed.
//Summary of Function: Identifies the smallest item in the binary tree and removes it.
    char * item; //Initialize item.

    bst_node *group1 = *root; //Initialize group1 to the root
	bst_node *group2 = *root; //Initialize group2 to the root

	if (*root != NULL){ //If the root pointer is not empty
		if ((*root) -> left == NULL){ //If the left is empty
			item = group1 -> data; //The item variable is set to group1's data.
			*root = group1 -> right; //The root is set to group1's right child/
			free(group1); //Freeing up the memory for group1.
			return item; //Returning the smallest item.
		} else if (((*root) -> left == NULL) && ((*root) -> right == NULL)){ //If the left and right child is empty.
			item = (*root) -> data; //The item is simply the root data.
			free(*root); //Free the memory allocated to *root.
			*root = NULL; //The root is set to NULL, since removed
			return item; //Return the smallest item.
		}
		while ((group2 -> left) != NULL){ //While group2's left child is not empty.
			group2 = group2 -> left; //Group2 loops through all left children.
		}
		if (group1 != group2){ //If group1 and 2 are not equal
			while ((group1 -> left) != group2){ //While group1's left child is not equal to group2
				group1 = group1 -> left; //Group1 loops through all left children
			}
		}
		if (group1 == group2){ //If group1 is equal to 2.
			*root = group2 -> right; //The root is set to group2's right child
			item = group1 -> data; //The item is set to group1's data.
			free(group1); //Freeing allocated memory
			return item; //Return smallest item
		} else {
			item = group2 -> data; //The item is set to group2's data
			group1 -> left = group2 -> right; //Group1's left child is set to group2's right child
			free(group2); //Freeing allocated memory
			return item; //Return smallest item
		}
	}
    return NULL; //Return
}


 
char * removeLargest (  bst_node ** root ){ //remove largest node, right-most child node
//Function Parameters: The root of the entire binary tree.
//Reurned Value: The item that was removed, even though it is never printed.
//Summary of function: Removes the largest node in the binary tree.
    char * item; //initializes item

    bst_node *group1 = *root; //Initialize group1 to the root
    bst_node *group2 = *root; //Initialize group2 to the root

    if (*root != NULL){ //If the root pointer is not empty
    	if (((*root) -> left == NULL) && ((*root) -> right == NULL)){ //If the left and right of the root is empty
    		item = (*root) -> data; //The data of root is set to item
    		free(*root); //Free up allocated memory
    		*root = NULL; //Root is now empty
    		return item; //Return largest node
    	} else if ((*root) -> right == NULL){ //If only the right node is empty
    		item = group1 -> data; //The item is set to group1's data 
    		*root = group1 -> left; //The root is now group1's left child
    		free(group1); //Free up allocated memory
    		return item; //Return largest
    	}
    	while ((group2 -> right) != NULL){ //While group2's right child is not empty
    		group2 = group2 -> right; //Loop through group2's right children
    	}
    	if (group1 != group2){ //If group1 and 2 are not equal
    		while ((group1 -> right) != group2){ //While group1's right child is not equal to group2
    			group1 = group1 -> right; //Loop through group1's right children
    		}
    	}
    	if (group1 == group2){ //If the two are equal
    		item = group1 -> data; //Largest item set to group1's node
    		*root = group2 -> right; //The root is set to group2's right child
    		free(group2); //Free allocated memory
    		return item; //Return largest item
    	} else {
    		item = group2 -> data; //Group2's data is set to largest item
    		group1 -> right = group2 -> left; //Group1's right child is now group2's left child
    		free(group2); //Free up allocated memory
    		return item; //Return largest item
    	}
    }
    return NULL; //Return
}


